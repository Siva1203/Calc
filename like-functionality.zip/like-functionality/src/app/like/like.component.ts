import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-like',
  templateUrl: './like.component.html',
  styleUrls: ['./like.component.css']
})
export class LikeComponent implements OnInit {
 count = 10;
 isLiked= false;
 result:any;

 onClick(){
  if(this.isLiked==false) {
  this.count = this.count+1;
  this.isLiked = true;
  }
  else{
    this.count = this.count-1;
    this.isLiked = false;
  }
 }

 add(number1:any,number2:any){
  this.result= parseInt(number1) + parseInt(number2);
 }

 sub(number1:any,number2:any){
  this.result= parseInt(number1)-parseInt(number2);
 }


  constructor() { }

  ngOnInit() {
  }

}
